//
//  MapViewController.swift
//  WorldTrotter
//
//  Created by Corwin, Tyler D on 2/6/18.
//  Copyright © 2018 Corwin, Tyler D. All rights reserved.
//

import UIKit

class MapViewController: UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("MapViewController loaded its view")
    }
    
    
}
