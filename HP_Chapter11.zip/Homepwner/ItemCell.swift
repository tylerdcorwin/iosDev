//
//  ItemCell.swift
//  Homepwner
//
//  Created by Corwin, Tyler D on 2/27/18.
//  Copyright © 2018 Corwin, Tyler D. All rights reserved.
//

import UIKit

class ItemCell: UITableViewCell {
    
}
